# app_flask_combined.py
from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_socketio import SocketIO, emit, join_room, leave_room
from datetime import datetime
from app.models.user import Patient, Doctor
from app.models.appointment import Appointment
from app.models.health_record import HealthRecord
from app.models.report import ReportGenerator
from app.models.notifier import EmailNotifier
from app.services.user_service import UserService
from app.services.appointment_service import AppointmentService
from app.services.health_service import HealthService
from flask import send_file
import os
from collections import defaultdict
import time


app = Flask(__name__)
app.secret_key = 'supersecretkey'
socketio = SocketIO(app)

# Services
user_service = UserService()
appt_service = AppointmentService()
health_service = HealthService()

# Dummy data
patient = Patient(1, "John Doe", "john@example.com", "MED123")
doctor = Doctor(2, "Dr. Smith", "smith@example.com", "Cardiology")
user_service.register(patient)
user_service.register(doctor)

# Login required middleware
def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_email' not in session:
            flash('You must be logged in to view this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@app.route('/')
def home():
    return redirect(url_for('register'))

@app.route('/home')
@login_required
def dashboard_home():
    user = user_service.get_by_email(session['user_email'])
    return render_template('home.html', patient=user, doctor=doctor)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        medical_id = request.form['medical_id']

        if user_service.get_by_email(email):
            flash('Email is already registered.', 'danger')
            return redirect(url_for('register'))

        new_user = Patient(user_id=len(user_service.users)+1, name=name, email=email, medical_id=medical_id)
        user_service.register(new_user)
        flash('Account created successfully! You can now log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        user = user_service.get_by_email(email)
        if user:
            session['user_email'] = user._email
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard_home'))  # redirect to /home
        flash('Invalid email address.', 'danger')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user_email', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/book', methods=['GET', 'POST'])
@login_required
def book():
    user = user_service.get_by_email(session['user_email'])
    if request.method == 'POST':
        reason = request.form['reason']
        date = request.form['date']
        appt = Appointment(
            appt_id=len(appt_service.appointments)+1,
            patient=user,
            doctor=doctor,
            date_time=datetime.strptime(date, '%Y-%m-%dT%H:%M'),
            reason=reason
        )
        appt_service.book(appt)
        flash('Appointment booked successfully!', 'success')
        notifier = EmailNotifier()
        notifier.send(user._email, f"Your appointment for '{reason}' has been booked.")
        return redirect(url_for('appointments'))
    return render_template('book.html')

@app.route('/appointments')
@login_required
def appointments():
    return render_template('appointments.html', appointments=appt_service.appointments)

@app.route('/report')
@login_required
def report():
    user = user_service.get_by_email(session['user_email'])

    # Create user-specific report folder
    user_folder = f"static/reports/{user._name.replace(' ', '_')}/"
    os.makedirs(user_folder, exist_ok=True)

    # Generate timestamped filename
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"health_summary_{timestamp}.pdf"
    filepath = os.path.join(user_folder, filename)

    # Generate and save the PDF
    record = HealthRecord(
        record_id=len(user.records) + 1,
        patient_id=user._user_id,
        date=datetime.today().date(),
        bp="120/80",
        sugar=90,
        bmi=24.5
    )
    health_service.add_record(record)
    user.records.append(record)

    report = ReportGenerator(user)
    report.generate_pdf(filepath)

    return send_file(filepath, mimetype='application/pdf', download_name=filename, as_attachment=False)

@app.route('/report-history')
@login_required
def report_history():
    user = user_service.get_by_email(session['user_email'])
    folder = f"static/reports/{user._name.replace(' ', '_')}/"
    grouped_reports = defaultdict(list)

    if os.path.exists(folder):
        for file in os.listdir(folder):
            if file.endswith('.pdf'):
                filepath = os.path.join(folder, file)
                timestamp = os.path.getmtime(filepath)
                date_str = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
                month_key = time.strftime('%B %Y', time.localtime(timestamp))
                grouped_reports[month_key].append({'file': file, 'date': date_str})

    # Sort months and files inside each group
    sorted_grouped = dict(sorted(grouped_reports.items(), reverse=True))

    return render_template("report_history.html", grouped_reports=sorted_grouped)

@app.route('/delete-report', methods=['POST'])
@login_required
def delete_report():
    user = user_service.get_by_email(session['user_email'])
    filename = request.form['file']
    folder = f"static/reports/{user._name.replace(' ', '_')}/"
    filepath = os.path.join(folder, filename)

    if os.path.exists(filepath):
        os.remove(filepath)
        flash(f"{filename} deleted.", "success")
    else:
        flash("File not found.", "danger")

    return redirect(url_for('report_history'))


@app.route('/download-report')
@login_required
def download_report():
    return send_file("static/health_summary.pdf", as_attachment=True)


@app.route('/dashboard')
@login_required
def dashboard():
    user = user_service.get_by_email(session['user_email'])
    health_data = [{
        'date': r.date.strftime('%Y-%m-%d'),
        'bp': r.bp,
        'sugar': r.sugar,
        'bmi': r.bmi
    } for r in user.records]
    return render_template('dashboard.html', health_data=health_data)

@app.route('/chat')
@login_required
def chat():
    user = user_service.get_by_email(session['user_email'])
    return render_template('chat.html', user=user._name)

@socketio.on('join')
def handle_join(data):
    room = data['room']
    join_room(room)
    emit('status', {'msg': f"{data['user']} has joined the room."}, room=room)

@socketio.on('message')
def handle_message(data):
    room = data['room']
    emit('message', {
        'user': data['user'],
        'msg': data['msg'],
        'timestamp': data['timestamp']
    }, room=room)

@socketio.on('leave')
def handle_leave(data):
    room = data['room']
    leave_room(room)
    emit('status', {'msg': f"{data['user']} has left the room."}, room=room)

if __name__ == '__main__':
    socketio.run(app, debug=True)
