# services.py
class AppointmentService:
    def __init__(self):
        self.appointments = []

    def book_appointment(self, appointment):
        self.appointments.append(appointment)
        return appointment

    def cancel_appointment(self, appt_id):
        for appt in self.appointments:
            if appt.appt_id == appt_id:
                appt.cancel()
                return True
        return False


class UserService:
    def __init__(self):
        self.users = []

    def register_user(self, user):
        self.users.append(user)
        return user

    def get_user_by_email(self, email):
        return next((u for u in self.users if u._email == email), None)