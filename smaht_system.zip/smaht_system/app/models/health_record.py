# health_record.py
class HealthRecord:
    def __init__(self, record_id, patient_id, date, bp, sugar, bmi):
        self.record_id = record_id
        self.patient_id = patient_id
        self.date = date
        self.bp = bp
        self.sugar = sugar
        self.bmi = bmi

    def get_record(self):
        return {
            "Record ID": self.record_id,
            "Patient ID": self.patient_id,
            "Date": self.date,
            "Blood Pressure": self.bp,
            "Sugar Level": self.sugar,
            "BMI": self.bmi
        }