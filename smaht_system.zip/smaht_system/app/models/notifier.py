# notifier.py
from abc import ABC, abstractmethod

class Notifier(ABC):
    @abstractmethod
    def send(self, recipient, message):
        pass


class EmailNotifier(Notifier):
    def send(self, recipient, message):
        print(f"Sending email to {recipient}: {message}")


class SMSNotifier(Notifier):
    def send(self, recipient, message):
        print(f"Sending SMS to {recipient}: {message}")