# main.py
from datetime import datetime
from app.models.user import Patient, Doctor
from app.models.appointment import Appointment
from app.models.health_record import HealthRecord
from app.models.report import ReportGenerator
from app.models.notifier import EmailNotifier
from app.services.user_service import UserService
from app.services.appointment_service import AppointmentService
from app.services.health_service import HealthService

# Instantiate services
user_service = UserService()
appt_service = AppointmentService()
health_service = HealthService()

# Register users
patient = Patient(1, "John Doe", "john@example.com", "MED123")
doctor = Doctor(2, "Dr. Smith", "smith@example.com", "Cardiology")
user_service.register(patient)
user_service.register(doctor)

# Create appointment
appt = Appointment(1001, patient, doctor, datetime.now(), "Routine Check")
appt_service.book(appt)

# Add health record
record = HealthRecord(1, patient._user_id, datetime.today().date(), "120/80", 90, 24.5)
health_service.add_record(record)
patient.records.append(record)

# Generate PDF report
report = ReportGenerator(patient)
report.generate_pdf("health_summary.pdf")

# Send confirmation
notifier = EmailNotifier()
notifier.send(patient._email, "Appointment confirmed for today!")

# Display output
data = appt.get_summary()
print("\nAppointment Summary:")
for k, v in data.items():
    print(f"{k}: {v}")