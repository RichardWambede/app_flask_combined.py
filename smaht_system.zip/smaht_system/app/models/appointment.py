# appointment.py
class Appointment:
    def __init__(self, appt_id, patient, doctor, date_time, reason):
        self.appt_id = appt_id
        self.patient = patient
        self.doctor = doctor
        self.date_time = date_time
        self.reason = reason
        self.status = "Scheduled"

    def cancel(self):
        self.status = "Cancelled"

    def reschedule(self, new_datetime):
        self.date_time = new_datetime
        self.status = "Rescheduled"

    def get_summary(self):
        return {
            "Appointment ID": self.appt_id,
            "Patient": self.patient._name,
            "Doctor": self.doctor._name,
            "Date/Time": self.date_time,
            "Reason": self.reason,
            "Status": self.status
        }