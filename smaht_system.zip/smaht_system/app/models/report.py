# report.py

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
import os

class ReportGenerator:
    def __init__(self, patient):
        self.patient = patient

    def generate_pdf(self, filename):
        c = canvas.Canvas(filename, pagesize=A4)
        width, height = A4

        # Load logo (make sure 'logo.png' is inside the 'static/' folder)
        logo_path = os.path.join("static", "logo.png")
        if os.path.exists(logo_path):
            logo = ImageReader(logo_path)
            c.drawImage(logo, x=50, y=height - 100, width=100, height=60, preserveAspectRatio=True)

        # Add title and details
        c.setFont("Helvetica-Bold", 16)
        c.drawString(160, height - 80, f"Health Summary Report")

        c.setFont("Helvetica", 12)
        c.drawString(50, height - 130, f"Patient: {self.patient._name}")
        c.drawString(50, height - 150, f"Medical ID: {self.patient.medical_id}")
        c.drawString(50, height - 170, f"Email: {self.patient._email}")

        # Add health records
        y = height - 210
        for record in self.patient.records:
            text = f"{record.date} - BP: {record.bp}, Sugar: {record.sugar}, BMI: {record.bmi}"
            c.drawString(50, y, text)
            y -= 20

        c.save()