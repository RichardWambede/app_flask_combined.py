# user.py
from abc import ABC, abstractmethod

class User(ABC):
    def __init__(self, user_id, name, email):
        self._user_id = user_id
        self._name = name
        self._email = email

    @abstractmethod
    def get_details(self):
        pass


class Patient(User):
    def __init__(self, user_id, name, email, medical_id):
        super().__init__(user_id, name, email)
        self.medical_id = medical_id
        self.records = []

    def get_details(self):
        return {
            "ID": self._user_id,
            "Name": self._name,
            "Email": self._email,
            "Medical ID": self.medical_id,
            "Records": self.records
        }


class Doctor(User):
    def __init__(self, user_id, name, email, specialization):
        super().__init__(user_id, name, email)
        self.specialization = specialization
        self.patients = []

    def get_details(self):
        return {
            "ID": self._user_id,
            "Name": self._name,
            "Email": self._email,
            "Specialization": self.specialization
        }


class Admin(User):
    def __init__(self, user_id, name, email):
        super().__init__(user_id, name, email)

    def get_details(self):
        return {
            "ID": self._user_id,
            "Name": self._name,
            "Email": self._email
        }