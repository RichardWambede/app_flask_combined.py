import json

class SimpleDB:
    def __init__(self, filepath):
        self.filepath = filepath

    def load_data(self):
        try:
            with open(self.filepath, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            return []

    def save_data(self, data):
        with open(self.filepath, 'w') as f:
            json.dump(data, f, indent=4)