
from app.models.health_record import HealthRecord

class HealthService:
    def __init__(self):
        self.records = []

    def add_record(self, record):
        self.records.append(record)
        return record

    def get_by_patient(self, patient_id):
        return [r for r in self.records if r.patient_id == patient_id]