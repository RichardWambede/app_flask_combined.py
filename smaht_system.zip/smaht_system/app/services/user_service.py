
from app.models.user import Patient, Doctor, Admin

class UserService:
    def __init__(self):
        self.users = []

    def register(self, user):
        self.users.append(user)
        return user

    def get_by_email(self, email):
        for user in self.users:
            if user._email == email:
                return user
        return None