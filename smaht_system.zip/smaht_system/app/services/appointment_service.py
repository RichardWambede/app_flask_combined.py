
from app.models.appointment import Appointment

class AppointmentService:
    def __init__(self):
        self.appointments = []

    def book(self, appointment):
        self.appointments.append(appointment)
        return appointment

    def cancel(self, appt_id):
        for appt in self.appointments:
            if appt.appt_id == appt_id:
                appt.cancel()
                return True
        return False