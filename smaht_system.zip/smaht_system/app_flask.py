from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
from app.models.user import Patient, Doctor
from app.models.appointment import Appointment
from app.models.health_record import HealthRecord
from app.models.report import ReportGenerator
from app.models.notifier import EmailNotifier
from app.services.user_service import UserService
from app.services.appointment_service import AppointmentService
from app.services.health_service import HealthService

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Services
user_service = UserService()
appt_service = AppointmentService()
health_service = HealthService()

# Dummy data
patient = Patient(1, "John Doe", "john@example.com", "MED123")
doctor = Doctor(2, "Dr. Smith", "smith@example.com", "Cardiology")
user_service.register(patient)
user_service.register(doctor)

# Middleware for login-required routes
def login_required(f):
    def wrapper(*args, **kwargs):
        if 'user_email' not in session:
            flash('You must be logged in to view this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@app.route('/')
@login_required
def home():
    user = user_service.get_by_email(session['user_email'])
    return render_template('home.html', patient=user, doctor=doctor)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        user = user_service.get_by_email(email)
        if user:
            session['user_email'] = user._email
            flash('Login successful!', 'success')
            return redirect(url_for('home'))
        flash('Invalid email address.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_email', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/book', methods=['GET', 'POST'])
@login_required
def book():
    user = user_service.get_by_email(session['user_email'])
    if request.method == 'POST':
        reason = request.form['reason']
        date = request.form['date']
        appt = Appointment(
            appt_id=len(appt_service.appointments)+1,
            patient=user,
            doctor=doctor,
            date_time=datetime.strptime(date, '%Y-%m-%dT%H:%M'),
            reason=reason
        )
        appt_service.book(appt)
        flash('Appointment booked successfully!', 'success')
        notifier = EmailNotifier()
        notifier.send(user._email, f"Your appointment for '{reason}' has been booked.")
        return redirect(url_for('appointments'))
    return render_template('book.html')

@app.route('/appointments')
@login_required
def appointments():
    return render_template('appointments.html', appointments=appt_service.appointments)

@app.route('/report')
@login_required
def report():
    user = user_service.get_by_email(session['user_email'])
    record = HealthRecord(1, user._user_id, datetime.today().date(), "120/80", 90, 24.5)
    health_service.add_record(record)
    user.records.append(record)
    report = ReportGenerator(user)
    report.generate_pdf("static/health_summary.pdf")
    flash('PDF report generated successfully.', 'info')
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    user = user_service.get_by_email(session['user_email'])
    health_data = [{
        'date': r.date.strftime('%Y-%m-%d'),
        'bp': r.bp,
        'sugar': r.sugar,
        'bmi': r.bmi
    } for r in user.records]
    return render_template('dashboard.html', health_data=health_data)

if __name__ == '__main__':
    app.run(debug=True)