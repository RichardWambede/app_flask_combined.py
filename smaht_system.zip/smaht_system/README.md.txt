# SMART MEDICAL APPOINTMENT & HEALTH TRACKER SYSTEM (SMAHT)

This is a modular, OOP-based Python system for managing patient appointments, health records, and notifications.

## Features:
- User management (Admin, Doctor, Patient)
- Book/reschedule/cancel appointments
- Track health metrics (BP, Sugar, BMI)
- Export patient reports to PDF
- Notify users via email/SMS

To run:
```bash
pip install -r requirements.txt
python main.py
```

Structure:
- `models/`: Core domain logic
- `services/`: Business rules
- `utils/`: File and DB operations
- `main.py`: Entry point demo
